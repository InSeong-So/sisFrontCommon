///
// use jQuery

var Dom = Dom || {};

Dom.clearContainer = function( containerId )
{
    this.getContainer(containerId).innerHTML = '';
};

Dom.getContainer = function( containerId )
{
    var container = $(containerId);
    if( !container )
    {
        throw('Error: container with id="' + containerId + '" not found.');
    }
    return container;
};

Dom.createContainer = function(containerId, className)
{        
	var container = $(document.createElement("div"));
	container.id = containerId;
	if(className)
		container.className = className;
	
	return container;
};

Dom.isEnter = function( event )
{
    var keyCode = event.keyCode || event.which;
    return 13 == keyCode;
};

Dom.isDisable = function(containerId)
{
	var container = Dom.getContainer(containerId);
	if(container.className == "disable")
		return true;
	else
		return false;
}

var Row = Class.create(
{
    initialize: function( id, classType )
    {
        this.cellType = 'td';
        if( null != id && "undefined" != id && null != classType)
            this.domRow = new Element('tr', {id:id, class:classType});
        else if ( null != id && "undefined" != id )
            this.domRow = new Element('tr', {id:id});
        else
            this.domRow = new Element('tr');
    },

    addCell: function( contents )
    {
        var td = new Element(this.cellType);
        if( 'string' == typeof contents )
        {
            td.update(contents);
        }
        else
        {
            td.insert(contents);
        }
        this.domRow.insert(td);
    },

    addCellWithSpaceIfEmpty: function( contents )
    {
        if( null != contents && "" != contents )
            this.addCell(contents);
        else
        {
            var td = new Element(this.cellType);
            td.insert("&nbsp;");
            this.domRow.insert(td);
        }
    },

    addRealCell: function( cell )
    {
        this.domRow.insert(cell);
    },

    findInContainer: function( containerId )
    {
        var container = Dom.getContainer(containerId);
        var row;
        $A(container.childElements()).each(function( each )
        {
            if( this.id == each.readAttribute('id') )
            {
                row = each;
                throw $break;
            }
        }.bind(this));
        return row;
    },

    addToContainer: function( containerId )
    {
        var domRow = this.findInContainer(containerId);
        if( undefined == domRow )
        {
            Dom.getContainer(containerId).insert(this.domRow);
        }
    },

    removeFromContainer: function( containerId )
    {
        var row = this.findInContainer(containerId);
        if( undefined != row )
        {
            row.remove();
        }
    }
});


var HeaderRow = Class.create(Row, {
    initialize: function( $super, name, id )
    {
        $super(name, id);
        this.cellType = 'th';
    }
});


var Cell = Class.create({
	
    initialize: function( id )
    {
        if( null != id && "undefined" != id )
        	this.domCell = new Element('td', {id:id});
        else
            this.domCell = new Element('td');
    },

    addContents: function( contents )
    {
        if( 'string' == typeof contents )
            this.domCell.update(contents);
        else
            this.domCell.insert(contents);

        return this.domCell;
    },
    
    addColspan: function(colspan)
    {
    	Element.writeAttribute(this.domCell, {colspan:colspan});
    },
    
    addClassName: function(className)
    {
    	Element.addClassName(this.domCell, className);
    }
});


//var Select = Class.create({
//    initialize: function( id, className, name, disabled )
//    {
//        this.id = id;
//        this.name = name;
//        this.valueKey = 'value';
//        this.textKey = 'text';
//        if( disabled )
//            this.select = new Element('select', {id:id, disabled:disabled});
//        else
//            this.select = new Element('select', {id:id});
//        this.select.addClassName(className);
//    },
//
//    setValueKey: function( key )
//    {
//        this.valueKey = key;
//    },
//
//    setTextKey: function( key )
//    {
//        this.textKey = key;
//    },
//
//    addOptions: function( options, selectedOption, onClickAction )
//    {
//        options.each(function( option )
//        {
//            this.addOption(option, selectedOption, onClickAction);
//        }.bind(this));
//    },
//
//    addOption: function( option, selectedOption, onClickAction )
//    {
//        var value = this.valueKey ? option[this.valueKey] : option;
//        var text = this.textKey ? option[this.textKey] : option;
//        if( null != selectedOption && value == selectedOption )
//            var option = new Element('option', {value:value, selected:"selected"}).update(text);
//        else
//            var option = new Element('option', {value:value}).update(text);
//
//        if( null != onClickAction )
//            Event.observe(option, 'click', onClickAction.bind(this));
//        this.select.insert(option);
//    },
//
//    addToElement: function( elementId )
//    {
//        $(elementId).insert(this.select);
//    }
//});


var DomIdentifiedObject = Class.create(
{
    initialize: function( identifiedObject )
    {
        this.id = identifiedObject.id;
        this.code = identifiedObject.code;
    },

    findInContainer: function( containerId )
    {
        var container = Dom.getContainer(containerId);
        var row;
        $A(container.childElements()).each(function( each )
        {
            if( this.id == each.readAttribute('id') )
            {
                row = each;
                throw $break;
            }
        }.bind(this));
        return row;
    },

    removeFromContainer: function( containerId )
    {
        var row = this.findInContainer(containerId);
        if( undefined != row )
        {
            row.remove();
        }
    },

    getBindedButton: function( text, callback, id )
    {
        if( id )
            var button = new Element('input', {type: 'button', value: text, id: id});
        else
            var button = new Element('input', {type: 'button', value: text});
        button.observe('click', callback.bindAsEventListener(this));
        return button;
    },

    getInputText: function( idInput, nameInput, valueInput, classInput, actionForOnBlur )
    {
        var input = new Element('input', {type: 'text', name:nameInput, id:idInput, value:valueInput, onBlur:actionForOnBlur});
        input.addClassName(classInput);
        return input;
    },

    getCheckBox: function( idInput, nameInput, valueInput, actionForOnBlur )
    {
        var input = new Element('input', {type: 'checkbox', name:nameInput, checked:( "true" == valueInput ), id:idInput, onBlur:actionForOnBlur});
        return input;
    },
    
    getBindedText: function(text, callback)
    {
        var text = new Element('a', {class: 'bindedText'}).update(text);
        text.observe('click', callback.bindAsEventListener(this));
        return text;
    },
    
    getLink: function( text, url)
    {
        var link = new Element('a', {href: url}).update(text);
        return link;
    }

});

function disableContainer( containerId )
{
    var container = Dom.getContainer( containerId );
    container.addClassName( "disable" );
}

function enableContainer( containerId )
{
    var container = Dom.getContainer( containerId );
    container.removeClassName( "disable" );
}

