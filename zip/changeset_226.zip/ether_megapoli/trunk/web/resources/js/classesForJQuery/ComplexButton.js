//********************************************************
// Class Button
// Display a button
//
// use jQuery
// str value: Value to display in the button
// dom parent: in which dom element to draw the button
// int id: id of the dom element
// func onclick: callback function when button clicked
// str specificClass
// classNameToAdd : use to avoid button's style for button_left, button_right and button_middle when button.css is used with pagination.css
//********************************************************

var ComplexButton = Class.create( {

    initialize: function( param )
    {
        // Init
        this.id = param.id ? param.id : "";
        this.parent = param.parent ? param.parent : false;
        this.value = param.value ? param.value : "";
        this.specificClass = param.specificClass ? param.specificClass : "";
        this.callbackOnClick = param.onClick ? param.onClick : false;
        this.boolDisabled = false;
        this.boolSelected = false;
        this.boolDisplayed = false;

        // Create button elements
        this.divContainer = $( document.createElement( "div" ) );
        this.divContainer.addClass( "complexButton" );
        this.divContainer.atMe = this;
        this.divContainer.id = this.id;
        this.divContainer.addClass( this.specificClass );
        if( this.parent )
        {
            this.parent.append( this.divContainer );
        }

        this.divLeft = $( document.createElement( "div" ) );
        if( param.classNameToAdd )
            this.divLeft.addClass( "complexButton_left_" + param.classNameToAdd );
        else
            this.divLeft.addClass( "complexButton_left" );
        this.divContainer.append( this.divLeft );

        this.divMiddle = $( document.createElement( "div" ) );
        if( param.classNameToAdd )
            this.divMiddle.addClass( "complexButton_middle_" + param.classNameToAdd );
        else
            this.divMiddle.addClass( "complexButton_middle" );
        this.divContainer.append( this.divMiddle );

        this.divText = $( document.createElement( "div" ) );
        this.divText.addClass( "complexButton_text" );
        this.divText.html( this.value );
        this.divMiddle.append( this.divText );

        this.divRight = $( document.createElement( "div" ) );
        if( param.classNameToAdd )
            this.divRight.addClass( "complexButton_right_" + param.classNameToAdd );
        else
            this.divRight.addClass( "complexButton_right" );
        this.divContainer.append( this.divRight );

        // Define button events
        this.divContainer.bind( 'click', this, this.onClick );
//        Event.observe( this.divContainer, 'click', this.onClick.bindAsEventListener( this ) );
//        Event.observe( this.divContainer, 'mouseover', this.onHover.bindAsEventListener( this ) );
    },

    // Actions ********************************************************

    appendChild :function( parent )
    {
        this.parent = parent;
        this.parent.append( this.divContainer );
    },

    setDisabled:function( value )
    {
        if( value )
        {
            this.disable();
        }
        else
        {
            this.enable();
        }
    },

    disable : function()
    {
        this.boolDisabled = true;
        this.divContainer.addClassName( "disable" );
    },

    enable : function()
    {
        this.boolDisabled = false;
        this.divContainer.removeClassName( "disable" );
    },

    setSelected : function( value )
    {
        this.boolSelected = value;
        if( this.boolSelected )
        {
            this.divContainer.addClassName( "selected" );
        }
        else
        {
            this.divContainer.removeClassName( "selected" );
        }
    },

    show : function()
    {
        this.boolDisplayed = true;
        this.divContainer.style.display = "";
    },

    hide : function()
    {
        this.boolDisplayed = false;
        this.divContainer.style.display = "none";
    },

    // Getter / Setter ********************************************************

    getContainer: function()
    {
        return this.divContainer;
    },

    getDisable : function()
    {
        return this.boolDisabled;
    },

    getSelect: function()
    {
        return this.boolSelected;
    },

    setValue : function( value )
    {
        this.value = value;
        this.divText.html( this.value );
    },

    setCallbackOnClick : function( value )
    {
        this.callbackOnClick = value;
    },

    // Events ********************************************************

    onClick : function( event )
    {
        if( !event.data.getDisable() && (undefined == event.detail || 1 == event.detail) && event.data.callbackOnClick )
            event.data.callbackOnClick();
    }
} );
